from kenessa import Province

def main():
    print Province('1').province()



