from myrw import Province

def main():
    print Province('1').province()



